PUBLICAÇÃO NO GITHUB PAGES
===========================

1. Criar um repositório no GitHub.
2. Enviar o arquivo index.html para a raiz do repositório.
3. Acessar Settings > Pages.
4. Selecionar Deploy from a branch.
5. Selecionar branch main e pasta /root.
6. Salvar e aguardar o link do GitHub Pages.

Arquivo dashboard criado por Otávio João Felisberto, da Área Técnica do Grupo SC — Florianópolis.
